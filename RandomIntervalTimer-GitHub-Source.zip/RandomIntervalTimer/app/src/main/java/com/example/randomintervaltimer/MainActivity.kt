package com.example.randomintervaltimer

import android.app.Activity
import android.os.Bundle
import android.os.Handler
import android.os.Looper
import android.speech.tts.TextToSpeech
import android.media.AudioManager
import android.media.ToneGenerator
import android.view.Gravity
import android.view.WindowManager
import android.widget.Button
import android.widget.LinearLayout
import android.widget.TextView
import java.util.Locale
import kotlin.random.Random

class MainActivity : Activity(), TextToSpeech.OnInitListener {
    private val handler = Handler(Looper.getMainLooper())
    private var tts: TextToSpeech? = null
    private var tone: ToneGenerator? = null
    private lateinit var status: TextView
    private lateinit var timer: TextView
    private lateinit var startPause: Button
    private var running = false
    private var phase = "idle" // work, rest, done
    private var totalLeft = 90 * 60_000L
    private var phaseLeft = 0L
    private var lastTick = 0L
    private val tick = object : Runnable {
        override fun run() {
            if (!running) return
            val now = System.currentTimeMillis()
            val delta = (now - lastTick).coerceAtLeast(0L)
            lastTick = now
            totalLeft = (totalLeft - delta).coerceAtLeast(0L)
            phaseLeft = (phaseLeft - delta).coerceAtLeast(0L)

            if (totalLeft <= 0L) {
                finishCycle()
                return
            }
            if (phaseLeft <= 0L) {
                if (phase == "work") {
                    phase = "rest"
                    phaseLeft = 10_000L
                    speak("停止")
                } else {
                    phase = "work"
                    phaseLeft = Random.nextLong(180_000L, 300_001L)
                    speak("开始")
                }
            }
            refresh()
            handler.postDelayed(this, 200)
        }
    }

    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        window.addFlags(WindowManager.LayoutParams.FLAG_KEEP_SCREEN_ON)
        tts = TextToSpeech(this, this)
        tone = ToneGenerator(AudioManager.STREAM_ALARM, 100)

        val layout = LinearLayout(this).apply {
            orientation = LinearLayout.VERTICAL
            gravity = Gravity.CENTER
            setPadding(28, 36, 28, 36)
        }
        val title = TextView(this).apply {
            text = "随机间隔计时器"
            textSize = 26f
            gravity = Gravity.CENTER
        }
        status = TextView(this).apply {
            textSize = 20f
            gravity = Gravity.CENTER
            setPadding(0, 32, 0, 12)
        }
        timer = TextView(this).apply {
            textSize = 38f
            gravity = Gravity.CENTER
            setPadding(0, 12, 0, 32)
        }
        startPause = Button(this).apply {
            text = "开始 90 分钟"
            setOnClickListener { toggle() }
        }
        val reset = Button(this).apply {
            text = "重置"
            setOnClickListener { resetTimer() }
        }
        layout.addView(title)
        layout.addView(status)
        layout.addView(timer)
        layout.addView(startPause)
        layout.addView(reset)
        setContentView(layout)
        refresh()
    }

    override fun onInit(result: Int) {
        if (result == TextToSpeech.SUCCESS) tts?.language = Locale.SIMPLIFIED_CHINESE
    }

    private fun toggle() {
        if (phase == "done") resetTimer()
        if (running) {
            running = false
            handler.removeCallbacks(tick)
            startPause.text = "继续"
        } else {
            if (phase == "idle") {
                totalLeft = 90 * 60_000L
                phase = "work"
                phaseLeft = Random.nextLong(180_000L, 300_001L)
            }
            running = true
            lastTick = System.currentTimeMillis()
            startPause.text = "暂停"
            handler.post(tick)
        }
        refresh()
    }

    private fun resetTimer() {
        running = false
        handler.removeCallbacks(tick)
        phase = "idle"
        totalLeft = 90 * 60_000L
        phaseLeft = 0L
        startPause.text = "开始 90 分钟"
        refresh()
    }

    private fun finishCycle() {
        running = false
        phase = "done"
        totalLeft = 0L
        handler.removeCallbacks(tick)
        speak("计时结束")
        startPause.text = "重新开始"
        refresh()
    }

    private fun speak(word: String) {
        tone?.startTone(ToneGenerator.TONE_PROP_BEEP, 700)
        tts?.speak(word, TextToSpeech.QUEUE_FLUSH, null, "timer-$word-${System.currentTimeMillis()}")
    }

    private fun refresh() {
        status.text = when (phase) {
            "work" -> "状态：工作中"
            "rest" -> "状态：休息倒计时（10 秒）"
            "done" -> "90 分钟计时结束"
            else -> "准备就绪：每隔随机 3～5 分钟提醒"
        }
        val shown = if (phase == "idle") totalLeft else if (phase == "done") 0L else phaseLeft
        timer.text = String.format(Locale.getDefault(), "%02d:%02d", shown / 60_000, (shown / 1000) % 60)
    }

    override fun onDestroy() {
        handler.removeCallbacks(tick)
        tts?.stop()
        tts?.shutdown()
        tone?.release()
        super.onDestroy()
    }
}
