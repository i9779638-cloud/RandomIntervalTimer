# 随机间隔计时器

Android app: 每隔随机 3～5 分钟语音提示“停止”，等待 10 秒后提示“开始”，总周期 90 分钟。包含暂停、继续和重置。

## 在线编译
仓库配置了 GitHub Actions。推送到 `main` 分支会自动编译；也可以在 Actions 页面手动运行 `Build Android APK`。完成后在运行记录的 Artifacts 中下载 `RandomIntervalTimer-debug-apk`。

## 注意
当前版本在应用前台运行时计时；请保持应用打开并避免系统清理应用。语音音量受手机媒体/闹钟音量和系统 TTS 设置影响。
